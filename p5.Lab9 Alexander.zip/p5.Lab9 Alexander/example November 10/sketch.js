var x = 80;

var x2 = 20;

var y = 50;

var y2 = 20;

var w = 80;

var h = 60;

var w2 = 10;

var h2 = 5;

var radius = 12;

var ping;

var sine;

var freq = 400;


function preload() {
	ping = loadSound("jump.mp3");
}

function setup() {

	let cnv = createCanvas(440, 440);

	cnv.mousePressed(userStartAudio);

  	mic = new p5.AudioIn();

  	mic.start();

  	osc = new p5.Oscillator('sine');

  	fill (255);

  	rect(x, y, w, h);

  	ellipseMode (RADIUS);

  	capture = createCapture();

	capture.hide();
	

}


function draw() {
		
		background(0);

  		micLevel = mic.getLevel();

  		let y2 = height - micLevel * height;

  		stroke (5);

   		background (100);

   		fill (0, 100, 250, 1.0);

		rect(x2, y2, w2, h2);

		colorMode(RGB, 255, 255, 255, 1);

		fill (100, 200, 100, 1.0);

		rect(x, y, w, h);


		var d = dist(mouseX, mouseY, x, y);

			if (d < radius) {

			osc.start();

  			osc.freq((1000 / mouseX * .8));

  			osc.amp(0.7);

			radius++;

  			fill(50, 20, 100, 1.0);

	}
	

	else {

		osc.stop();

  		osc.freq(0);

   		osc.amp(0);

	}

	
	ellipse(x, y, radius, radius);


	image(capture, 0, 0, width, h);
	filter(BLUR);
}




function mousePressed() {


		ping.play();


}

